LapTune 2.1.1 — gotowy obraz diagnostyczny dla NUCLEO-F103RB

Źródła: 74026455b083e9210e54fce0a91b2de84b7918e3
Konfiguracja: Release, czysty build (firmware_dirty=false).
HEX SHA-256: 581dea9f5f257906532a253bf7618fbb8f4f8a6f1c9765b8dfd582e80bf80087

1. Rozpakuj archiwum.
2. Połącz Nucleo przez ST-LINK z STM32CubeProgrammer.
3. Otwórz LapTune-2.1.1-7402645.hex i wykonaj programowanie z weryfikacją.
   HEX zawiera adresy, nie musisz wpisywać offsetu BIN.
   Kasuj strony wymagane przez obraz; nie wykonuj Full chip erase,
   aby zachować licznik sesji w końcowych dwóch stronach flash.
4. Uruchom płytkę przyciskiem RESET. CubeIDE Run/Debug może ponownie
   wgrać ELF wskazany w konfiguracji uruchomienia, więc do tej próby
   wystarczy RESET po programowaniu.
5. Po około 30 sekundach naciśnij B1, zaczekaj na SD SAVED i otwórz
   najnowszy SESSION.json z nowego folderu sesji.
6. Sprawdź firmware_version=2.1.1, firmware_commit=74026455b083e9210e54fce0a91b2de84b7918e3,
   oraz obecność pól gps_receiver_seen i gps_sats_with_cno.

Ta wersja zbiera diagnostykę NO FIX: C/N0, śledzenie satelitów,
stan anteny, flagi SOL i tryb pracy GPS. Nie jest potwierdzeniem
usunięcia fizycznej przyczyny braku fixa. Odczyty nie zapisują
ustawień anteny/trybu pracy i ustają po uzyskaniu fixa.

Format TXT pozostaje 36-kolumnowy. PPS: PA0/A0.
Szczegóły: docs/GPS_DIAGNOSTICS.md w repozytorium.
